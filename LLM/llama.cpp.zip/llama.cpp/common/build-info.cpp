int LLAMA_BUILD_NUMBER = 1568;
char const *LLAMA_COMMIT = "9656026";
char const *LLAMA_COMPILER = "cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0";
char const *LLAMA_BUILD_TARGET = "x86_64-linux-gnu";
